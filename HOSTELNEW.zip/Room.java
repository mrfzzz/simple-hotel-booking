package lab1vitualprogrammingw2;

public class Room {
	
private String RoomType;
private Double PayRate;

public Room(String type, double payRate) {
    this.RoomType = type;
    this.PayRate = payRate;
}

public Double getPayRate() {
	return PayRate;
	
}
public String getType() {
	return RoomType;
	
}
	
}
