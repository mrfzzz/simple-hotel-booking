package lab1vitualprogrammingw2;

import java.util.Scanner;

public class Student {

private String name;
private String room;
protected Double fees;



public void setDetails() {
	Scanner n =new Scanner(System.in);
	
	System.out.println("Enter your name :");
	String name = n.nextLine();
	this.name= name;	
}

public void setRoom() {
	Scanner r = new Scanner(System.in);
	System.out.println("Enter the room type that You like");
	String RoomType =r.nextLine();
	this.room =RoomType;	
}

public void displayDetails() {
	  System.out.println("Student Name: " + this.name);
      System.out.println("Room Type: " + this.room);
      
      switch(this.room) {
	    case"A":
	  	System.out.println("The fees of one year : RM "+450.00*2);
	  	break;
	    case"B":
		 System.out.println("The fees of one year : RM "+400.00*2);
		 break;
	    case"C":
	  		System.out.println("The fees of one year : RM "+350.00*2);
	  		break;
	  	default:
	  	System.out.println("Error");
	  	break;
	 }
	 
      
	
}

}
