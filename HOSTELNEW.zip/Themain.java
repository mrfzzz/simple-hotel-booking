package lab1vitualprogrammingw2;

public class Themain {

	public static void main(String[] args) {
		Student s = new Student();
		Room m = new Room(null, 0);
		Hostel h =new Hostel();
		
		
		Hostel.displayRoomType();
		s.setDetails();
		s.setRoom();
		s.displayDetails();
		m.getType();
		m.getPayRate();
	}

}
