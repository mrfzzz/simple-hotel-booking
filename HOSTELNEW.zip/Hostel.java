package lab1vitualprogrammingw2;

public class Hostel{
	private static Room[]room = {
			new Room("A",450.00),
			new Room("B",400.00),
			new Room("C",350.00),
	};
	
	public static void displayRoomType() {
	System.out.println("Welcome to The hostel booking system :)");
	System.out.println("Room Type Available:");
		for (Room room : room) {
			System.out.println(room.getType()+"-RM"+room.getPayRate()+"Per semester");
		}
	}

		
	}
